__version__ = "1.0.0"
MARKER = "OPTALE_PY_FIXTURE_OK"
