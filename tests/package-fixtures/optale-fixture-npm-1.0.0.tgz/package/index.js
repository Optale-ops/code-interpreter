module.exports = { version: '1.0.0', marker: 'OPTALE_NPM_FIXTURE_OK' };
