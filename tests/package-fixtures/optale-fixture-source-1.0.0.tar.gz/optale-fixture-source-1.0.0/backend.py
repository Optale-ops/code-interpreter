import base64, hashlib, os, zipfile
from pathlib import Path

def get_requires_for_build_wheel(config_settings=None):
    return []

def build_wheel(wheel_directory, config_settings=None, metadata_directory=None):
    Path('/mnt/data/pip-source-build-marker.txt').write_text('OPTALE_PIP_SOURCE_BUILD_OK')
    name = 'optale_fixture_source-1.0.0-py3-none-any.whl'
    payloads = {
        'optale_fixture_source/__init__.py': b'__version__ = "1.0.0"\nMARKER = "OPTALE_PIP_SOURCE_FIXTURE_OK"\n',
        'optale_fixture_source-1.0.0.dist-info/METADATA': b'Metadata-Version: 2.1\nName: optale-fixture-source\nVersion: 1.0.0\n',
        'optale_fixture_source-1.0.0.dist-info/WHEEL': b'Wheel-Version: 1.0\nGenerator: optale-source-fixture\nRoot-Is-Purelib: true\nTag: py3-none-any\n',
    }
    record = []
    for path, data in payloads.items():
        digest = base64.urlsafe_b64encode(hashlib.sha256(data).digest()).rstrip(b'=').decode()
        record.append(f'{path},sha256={digest},{len(data)}')
    record_path = 'optale_fixture_source-1.0.0.dist-info/RECORD'
    record.append(f'{record_path},,')
    payloads[record_path] = ('\n'.join(record) + '\n').encode()
    target = Path(wheel_directory) / name
    with zipfile.ZipFile(target, 'w', compression=zipfile.ZIP_DEFLATED) as wheel:
        for path in sorted(payloads):
            wheel.writestr(path, payloads[path])
    return name
